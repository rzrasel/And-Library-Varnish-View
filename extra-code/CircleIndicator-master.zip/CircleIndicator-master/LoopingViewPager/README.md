[LoopingViewPager](https://github.com/imbryk/LoopingViewPager)
================

An android ViewPager extension allowing infinite scrolling.
