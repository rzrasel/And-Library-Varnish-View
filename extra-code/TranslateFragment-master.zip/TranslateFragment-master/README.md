TranslateFragment
=================

Enter/Exit translate animation for Fragments

![fragment animation][1]

[1]: https://dl.dropboxusercontent.com/u/5854498/87qh5.gif
